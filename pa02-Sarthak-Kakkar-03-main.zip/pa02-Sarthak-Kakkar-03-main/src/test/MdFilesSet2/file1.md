# I don't have tests 
- [[This guy is just paranoid that he accidentally hard code AFTER DAYS]]
- btw, [[it's just a day before submission btw]]
- here are a couple what for testing? :::examples
- am i working? ::: idk let's see lol
- another question
- A [[question in ::: brackets]]
[[question without bullet? 
- :::
yes]]
[[question is this 
- :::answer is that]]
-[[main::: 
- that]]
- [[unique1 ::: unique2]] whateevrHHHHHHHHH [[unique3:::
unique 4]]

